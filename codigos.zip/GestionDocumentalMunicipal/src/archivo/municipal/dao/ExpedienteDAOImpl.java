package archivo.municipal.dao;

import archivo.municipal.modelo.Expediente;
import archivo.municipal.util.ConexionBD;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ExpedienteDAOImpl implements ExpedienteDAO {

    
    public boolean guardar(Expediente e) {
        String sql = "INSERT INTO expedientes (numero_expediente, id_area, asunto, responsable, fecha_apertura, estado, ubicacion) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection con = ConexionBD.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, e.getNumeroExpediente());
            ps.setInt(2, e.getIdArea());
            ps.setString(3, e.getAsunto());
            ps.setString(4, e.getResponsable());
            ps.setDate(5, Date.valueOf(e.getFechaApertura()));
            ps.setString(6, e.getEstado());
            ps.setString(7, e.getUbicacion());
            return ps.executeUpdate() > 0;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }

   
    public List<Expediente> listarTodos() {
        List<Expediente> lista = new ArrayList<>();
        String sql = "SELECT e.*, a.nombre as nombre_area FROM expedientes e JOIN areas a ON e.id_area = a.id_area ORDER BY e.id_expediente DESC";
        try (Connection con = ConexionBD.getConexion();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                Expediente exp = new Expediente();
                exp.setIdExpediente(rs.getInt("id_expediente"));
                exp.setNumeroExpediente(rs.getString("numero_expediente"));
                exp.setIdArea(rs.getInt("id_area"));
                exp.setNombreArea(rs.getString("nombre_area"));
                exp.setAsunto(rs.getString("asunto"));
                exp.setResponsable(rs.getString("responsable"));
                exp.setFechaApertura(rs.getDate("fecha_apertura").toLocalDate());
                exp.setEstado(rs.getString("estado"));
                exp.setUbicacion(rs.getString("ubicacion"));
                lista.add(exp);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return lista;
    }

    @Override
    public List<Expediente> buscar(String texto) {
        List<Expediente> lista = new ArrayList<>();
        String sql = "SELECT e.*, a.nombre as nombre_area FROM expedientes e JOIN areas a ON e.id_area = a.id_area " +
                     "WHERE e.numero_expediente LIKE ? OR e.asunto LIKE ? OR e.responsable LIKE ? ORDER BY e.id_expediente DESC";
        try (Connection con = ConexionBD.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            String filtro = "%" + texto + "%";
            ps.setString(1, filtro);
            ps.setString(2, filtro);
            ps.setString(3, filtro);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Expediente exp = new Expediente();
                    exp.setIdExpediente(rs.getInt("id_expediente"));
                    exp.setNumeroExpediente(rs.getString("numero_expediente"));
                    exp.setIdArea(rs.getInt("id_area"));
                    exp.setNombreArea(rs.getString("nombre_area"));
                    exp.setAsunto(rs.getString("asunto"));
                    exp.setResponsable(rs.getString("responsable"));
                    exp.setFechaApertura(rs.getDate("fecha_apertura").toLocalDate());
                    exp.setEstado(rs.getString("estado"));
                    exp.setUbicacion(rs.getString("ubicacion"));
                    lista.add(exp);
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return lista;
    }
}