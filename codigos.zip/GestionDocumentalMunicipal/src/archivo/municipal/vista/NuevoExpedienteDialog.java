package archivo.municipal.vista;

import archivo.municipal.modelo.Expediente;
import archivo.municipal.servicio.ExpedienteService;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.time.LocalDate;

public class NuevoExpedienteDialog extends JDialog {

    private JTextField txtNumero;
    private JComboBox<String> cbArea;
    private JTextField txtAsunto;
    private JTextField txtResponsable;
    private JComboBox<String> cbEstado;
    private JComboBox<String> cbUbicacion;

    private ExpedienteService expedienteService;
    private MenuPrincipalFrame padre;

    public NuevoExpedienteDialog(MenuPrincipalFrame padre) {
        super(padre, "Nuevo Expediente", true);
        this.padre = padre;
        this.expedienteService = new ExpedienteService();

        setSize(450, 480);
        setLocationRelativeTo(padre);
        setResizable(false);

        crearInterfaz();
    }

    private void crearInterfaz() {
        JPanel panel = new JPanel(new GridLayout(7, 2, 10, 15));
        panel.setBorder(new EmptyBorder(20, 20, 20, 20));
        panel.setBackground(Color.WHITE);

        panel.add(new JLabel("Número de expediente:"));
        txtNumero = new JTextField();
        panel.add(txtNumero);

        panel.add(new JLabel("Área:"));
        cbArea = new JComboBox<>(new String[]{"1 - Presidencia", "2 - Secretaría General", "3 - Sindicatura", "4 - Tesorería"});
        panel.add(cbArea);

        panel.add(new JLabel("Asunto:"));
        txtAsunto = new JTextField();
        panel.add(txtAsunto);

        panel.add(new JLabel("Responsable:"));
        txtResponsable = new JTextField();
        panel.add(txtResponsable);

        panel.add(new JLabel("Estado:"));
        cbEstado = new JComboBox<>(new String[]{"Abierto", "En proceso", "Cerrado"});
        panel.add(cbEstado);

        panel.add(new JLabel("Ubicación:"));
        cbUbicacion = new JComboBox<>(new String[]{"Archivo de trámite", "Archivo de concentración", "Archivo histórico"});
        panel.add(cbUbicacion);

        JButton btnGuardar = new JButton("Guardar");
        btnGuardar.setBackground(new Color(28, 110, 169));
        btnGuardar.setForeground(Color.WHITE);
        btnGuardar.setFocusPainted(false);
        btnGuardar.addActionListener(e -> guardarExpediente());

        JButton btnCancelar = new JButton("Cancelar");
        btnCancelar.addActionListener(e -> dispose());

        panel.add(btnGuardar);
        panel.add(btnCancelar);

        add(panel);
    }

    private void guardarExpediente() {
        String num = txtNumero.getText().trim();
        int idArea = cbArea.getSelectedIndex() + 1;
        String asunto = txtAsunto.getText().trim();
        String resp = txtResponsable.getText().trim();
        String estado = cbEstado.getSelectedItem().toString();
        String ubicacion = cbUbicacion.getSelectedItem().toString();

        if (num.isEmpty() || asunto.isEmpty() || resp.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor complete todos los campos obligatorios.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }

        Expediente exp = new Expediente(num, idArea, asunto, resp, LocalDate.now(), estado, ubicacion);

        if (expedienteService.registrarExpediente(exp)) {
            JOptionPane.showMessageDialog(this, "El expediente fue registrado correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            padre.cargarExpedientes();
            dispose();
        } else {
            JOptionPane.showMessageDialog(this, "Error al guardar el expediente.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}