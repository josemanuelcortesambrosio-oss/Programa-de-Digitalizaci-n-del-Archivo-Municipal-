package archivo.municipal.vista;

import archivo.municipal.modelo.Expediente;
import archivo.municipal.servicio.ExpedienteService;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class MenuPrincipalFrame extends JFrame {

    private JTable tablaExpedientes;
    private DefaultTableModel modeloTabla;
    private JTextField txtBuscar;
    private ExpedienteService expedienteService;

    public MenuPrincipalFrame() {
        expedienteService = new ExpedienteService();
        configurarVentana();
        crearInterfaz();
        cargarExpedientes();
    }

    private void configurarVentana() {
        setTitle("Sistema Integral de Gestión Documental y Archivo Municipal");
        setSize(950, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
    }

    private void crearInterfaz() {
        setLayout(new BorderLayout());

        JPanel barraSuperior = new JPanel(new BorderLayout());
        barraSuperior.setBackground(new Color(28, 110, 169));
        barraSuperior.setBorder(new EmptyBorder(15, 20, 15, 20));

        JLabel lblTitulo = new JLabel("H. Ayuntamiento de Villa Aldama - Archivo Municipal");
        lblTitulo.setForeground(Color.WHITE);
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 18));
        barraSuperior.add(lblTitulo, BorderLayout.WEST);

        JLabel lblUsuario = new JLabel("Usuario: admin ");
        lblUsuario.setForeground(Color.WHITE);
        lblUsuario.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        barraSuperior.add(lblUsuario, BorderLayout.EAST);

        add(barraSuperior, BorderLayout.NORTH);

        JPanel panelAcciones = new JPanel(new BorderLayout(15, 0));
        panelAcciones.setBorder(new EmptyBorder(15, 20, 15, 20));
        panelAcciones.setBackground(Color.WHITE);

        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        panelBotones.setBackground(Color.WHITE);

        JButton btnNuevo = new JButton("+ Nuevo expediente");
        btnNuevo.setBackground(new Color(40, 167, 69));
        btnNuevo.setForeground(Color.WHITE);
        btnNuevo.setFocusPainted(false);
        btnNuevo.addActionListener(e -> {
            NuevoExpedienteDialog dialog = new NuevoExpedienteDialog(this);
            dialog.setVisible(true);
        });

        JButton btnActualizar = new JButton("Actualizar");
        btnActualizar.addActionListener(e -> cargarExpedientes());

        panelBotones.add(btnNuevo);
        panelBotones.add(btnActualizar);

        JPanel panelBusqueda = new JPanel(new FlowLayout(FlowLayout.RIGHT, 5, 0));
        panelBusqueda.setBackground(Color.WHITE);
        txtBuscar = new JTextField(20);
        JButton btnBuscar = new JButton("Buscar");
        btnBuscar.addActionListener(e -> buscarExpedientes());

        panelBusqueda.add(new JLabel("Buscar:"));
        panelBusqueda.add(txtBuscar);
        panelBusqueda.add(btnBuscar);

        panelAcciones.add(panelBotones, BorderLayout.WEST);
        panelAcciones.add(panelBusqueda, BorderLayout.EAST);

        String[] columnas = {"ID", "Número", "Área", "Asunto", "Responsable", "Fecha Apertura", "Estado", "Ubicación"};
        modeloTabla = new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) { return false; }
        };

        tablaExpedientes = new JTable(modeloTabla);
        tablaExpedientes.setRowHeight(25);
        tablaExpedientes.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));

        JScrollPane scrollPane = new JScrollPane(tablaExpedientes);
        scrollPane.setBorder(new EmptyBorder(0, 20, 20, 20));

        JPanel centro = new JPanel(new BorderLayout());
        centro.setBackground(Color.WHITE);
        centro.add(panelAcciones, BorderLayout.NORTH);
        centro.add(scrollPane, BorderLayout.CENTER);

        add(centro, BorderLayout.CENTER);
    }

    public void cargarExpedientes() {
        modeloTabla.setRowCount(0);
        List<Expediente> lista = expedienteService.obtenerTodos();
        for (Expediente e : lista) {
            modeloTabla.addRow(new Object[]{
                    e.getIdExpediente(),
                    e.getNumeroExpediente(),
                    e.getNombreArea(),
                    e.getAsunto(),
                    e.getResponsable(),
                    e.getFechaApertura(),
                    e.getEstado(),
                    e.getUbicacion()
            });
        }
    }

    private void buscarExpedientes() {
        String texto = txtBuscar.getText().trim();
        modeloTabla.setRowCount(0);
        List<Expediente> lista = expedienteService.buscarExpedientes(texto);
        for (Expediente e : lista) {
            modeloTabla.addRow(new Object[]{
                    e.getIdExpediente(),
                    e.getNumeroExpediente(),
                    e.getNombreArea(),
                    e.getAsunto(),
                    e.getResponsable(),
                    e.getFechaApertura(),
                    e.getEstado(),
                    e.getUbicacion()
            });
        }
    }
}