package archivo.municipal.servicio;

import archivo.municipal.dao.ExpedienteDAO;
import archivo.municipal.dao.ExpedienteDAOImpl;
import archivo.municipal.modelo.Expediente;

import java.util.List;

public class ExpedienteService {
    private ExpedienteDAO expedienteDAO = new ExpedienteDAOImpl();

    public boolean registrarExpediente(Expediente expediente) {
        if (expediente.getNumeroExpediente() == null || expediente.getNumeroExpediente().trim().isEmpty()) {
            return false;
        }
        if (expediente.getAsunto() == null || expediente.getAsunto().trim().isEmpty()) {
            return false;
        }
        return expedienteDAO.guardar(expediente);
    }

    public List<Expediente> obtenerTodos() {
        return expedienteDAO.listarTodos();
    }

    public List<Expediente> buscarExpedientes(String texto) {
        if (texto == null || texto.trim().isEmpty()) {
            return obtenerTodos();
        }
        return expedienteDAO.buscar(texto);
    }
}